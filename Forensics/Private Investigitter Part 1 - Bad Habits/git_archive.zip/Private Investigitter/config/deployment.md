# CTF Deployment

Expert docker tip: run `docker compose up` to launch the CTF. The rest is simple!