# SESH Configurations

Some important config files. Can access these via a website for ease.

NOTE: DO NOT PUSH SENSITIVE AWS CREDENTIALS HERE!!!! We should be giving *instructions* for deploying applications, not credentials. Creds should be stored in password manager...

## How to run the server

```
$ php -S localhost:5000
```

## How to read a file

```
/view_files.php?file=[FILE]
```