<h1>View a config file</h1>

<?php
    $basepath = '/config/';
    $realBase = realpath($basepath);

    if (isset($_REQUEST['file'])) {
        $userpath = $basepath . $_REQUEST['file'];
        $realUserPath = realpath($userpath);

        if ($realUserPath === false || strcmp($realUserPath, $realBase) !== 0 || strpos($realUserPath, $realBase . DIRECTORY_SEPARATOR) !== 0) {
            echo("Nice try hacker");
        } else {
            include('/config/' . $_REQUEST['file']);
        }
    }
?>